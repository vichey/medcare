<?php

return [
    'logout' => 'ចាកចេញ'
];