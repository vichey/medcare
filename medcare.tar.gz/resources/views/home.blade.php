@extends('layouts.app')
@section('content')
<p><br></p>
<h2 align="center">សូមស្វា​គម​ន៏សំរាប់ការចូលគេហទំព័រ lysreyvyna clinic Admin</h2><hr>
@endsection
